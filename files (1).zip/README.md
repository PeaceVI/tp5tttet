# Gestion_Bib V3 (version refactoree)

Application Java de gestion d'une bibliotheque, refactoree pour ameliorer les metriques CK.

## Structure
```
src/library/
 +-- model/    Lendable (interface), Book, DigitalBook
 +-- service/  Library, Customer
 +-- util/     NumberClassifier   (ancienne complexMethodExample de Book)
 +-- app/      LibraryApp
```

## Compilation et execution (Windows : remplacer `/` par `\` et `:` par `;`)
```
javac --release 8 -d bin src/library/*/*.java
java -cp bin library.app.LibraryApp
```

## Analyse CKJM
```
java -cp ckjm-1.8.jar:<chemin>/rt.jar:bin gr.spinellis.ckjm.MetricsFilter bin/library/app/LibraryApp.class bin/library/model/*.class bin/library/service/*.class bin/library/util/*.class > metrics.txt
```
Note : sous JDK 9+, il n'y a plus de `rt.jar`. Sans lui, CKJM ne resout pas `java.lang.Object`
et affiche DIT = 0 partout. Utiliser un JRE 8 (`.../jre/lib/rt.jar`) pour des valeurs correctes.
Le code evite volontairement lambdas et references de methode, que CKJM 1.8 (BCEL ancien) ne sait pas lire.

## Changements par rapport a V2
1. **SRP** : `complexMethodExample` retiree de `Book` et placee dans `util.NumberClassifier`
   (logique separee de l'affichage, 2 petites methodes au lieu d'une methode imbriquee).
2. **Interface enrichie** : `Lendable` expose `isBorrowed()` et `getDescription()`.
   Plus de `instanceof`/cast dans `Library` ; `Library` ne depend plus de `Book`.
3. **Plus d'affichage dans model/service** : `borrow()`/`returnItem()` retournent un booleen,
   `Library.describeAllItems()` retourne des String. Seule `LibraryApp` affiche.
4. **Bug corrige** : `getAvailableItems()` filtre maintenant les objets empruntes.
5. **Encapsulation** : attributs `final`, listes exposees en lecture seule, `Customer.getName()` ajoute.
6. Retrait du token SonarQube du fichier de config (il etait publie sur GitHub : a revoquer) et des `.class` du depot.

## Metriques CKJM (WMC DIT NOC CBO RFC LCOM Ca NPM)

| Classe | V2 (avant) | V3 (apres) |
|---|---|---|
| Book | 7 1 1 1 13 **5** 3 7 | 7 1 1 1 **11** **0** 2 7 |
| DigitalBook | 2 2 0 1 3 0 1 2 | 3 2 0 1 9 0 1 3 |
| Lendable | 2 1 0 0 2 1 4 2 | 4 1 0 0 4 6 4 4 |
| Library | 5 1 0 2 **18** 0 1 5 | 6 1 0 **1** **16** 0 1 6 |
| Customer | 3 1 0 1 10 0 0 3 | 5 1 0 1 13 0 1 5 |
| LibraryApp | 2 1 0 4 10 1 0 2 | 2 1 0 6 23 1 0 2 |
| NumberClassifier | (n'existait pas) | 3 1 0 0 10 3 1 2 |

Ameliorations : LCOM de Book 5 -> 0, CBO de Library 2 -> 1, RFC de Library 18 -> 16 et de Book 13 -> 11,
plus aucune classe du service/model ne depend de `Book` concret.
Degradations : WMC en hausse (plus de petites methodes : getters, `isBorrowed`, `getDescription`),
CBO/RFC de `LibraryApp` en hausse (la demo utilise maintenant `Customer` et `NumberClassifier`),
LCOM de `Lendable` 1 -> 6 (artefact CKJM : une interface n'a pas d'attributs).
